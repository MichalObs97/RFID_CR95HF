#include "gui.h"


void gui_draw()
{
	
}