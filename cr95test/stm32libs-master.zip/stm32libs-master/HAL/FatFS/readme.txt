This is driver for SD card connected by SPI to STM32 for using with Chan's Fat FS. Lib written using HAL drivers.

example: https://github.com/SL-RU/stm32_file_viewer/
